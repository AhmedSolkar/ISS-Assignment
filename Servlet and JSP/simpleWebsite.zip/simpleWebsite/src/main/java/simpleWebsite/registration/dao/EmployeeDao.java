package simpleWebsite.registration.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import simpleWebsite.registration.model.Employee;

public class EmployeeDao {
	
	public int registerEmployee(Employee employee) throws ClassNotFoundException {
		String selectEmpQuery = "select count(*) from Employee";
		String insertEmpQuery = "insert into Employee VALUES" +
		" ( ?, ?, ?, ?, ?)";
		
		int result = 0;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		try (Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:orcl?useSSL=false", "scott", "TIGER")) {
			

            if (conn != null) {
                System.out.println("Connected to the database!");
            } else {
                System.out.println("Failed to make connection!");
            }
            
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(selectEmpQuery);
            rs.next();
            int count = rs.getInt(1);
            
			// Prepare Statement 
			PreparedStatement preparedStatement = conn.prepareStatement(insertEmpQuery);
			 // Set Parameters
			preparedStatement.setInt(1, count + 1);
			preparedStatement.setString(2, employee.getName());
			preparedStatement.setInt(3, employee.getAge());
			preparedStatement.setString(4, employee.getEmail());
			preparedStatement.setString(5, employee.getPassword());
			System.out.println(employee.getName());
			System.out.println(employee.getAge());
			System.out.println(employee.getEmail());
			System.out.println(employee.getPassword());
			System.out.println(preparedStatement); 
			// Execute SQL query
			result = preparedStatement.executeUpdate();
			System.out.println(result);
			
				
			conn.setAutoCommit(false);
			conn.commit();
			// Close the connection			
			conn.close();
        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            e.printStackTrace();            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//        	System.out.println("probs ans exception");
        }
		return result;
	}
	
	public int loginEmployee(Employee employee) throws ClassNotFoundException {
		String selectEmpQuery = "select count(*) from Employee where email=? and password=?";
		int count = 0;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		try (Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:orcl?useSSL=false", "scott", "TIGER")) {
			

            if (conn != null) {
                System.out.println("Connected to the database!");
            } else {
                System.out.println("Failed to make connection!");
            }
            
            
			// Prepare Statement 
			PreparedStatement preparedStatement = conn.prepareStatement(selectEmpQuery);
			 // Set Parameters);
			preparedStatement.setString(1, employee.getEmail());
			preparedStatement.setString(2, employee.getPassword());
			System.out.println(preparedStatement); 
			
		
			// Execute SQL query			
			ResultSet rs = preparedStatement.executeQuery();
			rs.next();
            count = rs.getInt(1);
			System.out.println(rs);
				
			conn.setAutoCommit(false);
			conn.commit();
			// Close the connection			
			conn.close();
        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            e.printStackTrace();            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//        	System.out.println("probs ans exception");
        }
		return count;
	}
}
